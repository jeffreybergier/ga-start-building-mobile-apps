import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var totalAmountLabel: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var billAmountTextField: UITextField!
    
    @IBAction func calculateTip(sender: UIButton) {
        // get the double value of the string in the text field
        let billAmount = Double(self.billAmountTextField.text!)!
        
        // hard code our tip percentage
        let tipPercentage = 0.2
        
        // calculate the tip amound and update the UI
        let tipAmount = billAmount * tipPercentage
        self.tipAmountLabel.text = "$\(tipAmount)"
        
        // calculate the total amount and update the UI
        let total = billAmount + tipAmount
        self.totalAmountLabel.text = "$\(total)"
    }
}

