import Foundation

// 1) Create an array
// 2) Get a name out
// 3) Index Out of Bounds
// 4) Create a dictionary
// 5) get an age out
// 6) get an age for a pet that does not exist
// 7) Mix and Match Array with Dictionary