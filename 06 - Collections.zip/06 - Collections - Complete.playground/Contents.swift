import Foundation

// 1) Create an array

let petNames = ["Jim", "Jones", "Fido"]

// 2) Get a name out

let myPet = petNames[2]

// 3) Index Out of Bounds

//let ghostPet = petNames[7]

// 4) Create a dictionary

let petAges = ["Jim" : 7, "Jones" : 4, "Fido" : 3]

// 5) get an age out

let myPetAge = petAges["Fido"]

// 6) get an age for a pet that does not exist

let ghostPetAge = petAges["Sam"]

// 7) Mix and Match Array with Dictionary

let jimAge = petAges[petNames[0]]