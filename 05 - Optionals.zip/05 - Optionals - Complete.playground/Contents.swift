import Foundation

// 1) Create optional string

var myString: String? = nil

// 2) Attempt to print the string

NSLog("\(myString)")

// 3) Force Unwrap it

//NSLog("\(myString!)")

// 4) Safely unwrap it

if let myString = myString {
    NSLog("\(myString)")
} else {
    NSLog("Oh dang, there was an error")
}
