import Foundation

// 1) Create optional string
// 2) Attempt to print the string
// 3) Force Unwrap it
// 4) Safely unwrap it
