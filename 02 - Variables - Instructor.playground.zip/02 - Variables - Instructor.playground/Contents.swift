// 1) Declare a constant String, Int, Double
// 2) Attempt to change constant
// 3) Declare new constants with type inference
// 4) Declare variable
// 5) Change value of variable
// 6) Attempt to change type of variable