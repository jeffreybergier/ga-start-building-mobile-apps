import Foundation

// 1) Create no argument function, call it

func humorMe() {
    NSLog("Knock knock")
}

humorMe()

// 2) Create 1 argument function, call it

func printNumber(number: Int) {
    NSLog("The number is: \(number)")
}

printNumber(7)

// 3) Create function with return value, call it

func squareNumber(number: Int) -> Int {
    return number * number
}

let squaredNumber = squareNumber(7)
NSLog("The square of 7 is \(squaredNumber)")
