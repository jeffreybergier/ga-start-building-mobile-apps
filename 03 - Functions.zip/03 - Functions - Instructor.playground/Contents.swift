import Foundation

// 1) Create no argument function, call it
// 2) Create 1 argument function, call it
// 3) Create function with return value, call it
