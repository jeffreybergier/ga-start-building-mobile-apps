
// 1) Declare a constant String, Int, Double
// Constants declared with 'let'

let myName: String = "Jared"
let myAge: Int = 45
let myShoeSize: Double = 7.5

// 2) Attempt to change constant
// If you attempt to change a constant you get a compiler error
// Uncomment the following line to see it

// myAge = 46

// 3) Declare new constants with type inference
// Swift Has Type Inference
// option click on the constant / variable name
// to see its inferred type

let myName2 = "Jared"
let myAge2 = 45
let myShoeSize2 = 7.5

// 4) Declare variable
// Variables declared with 'var'

var myStreetAddress = "272 Post St"

// 5) Change value of variable
// You can change constants
// if you moved to a new house

myStreetAddress = "474 Sutter St"

// 6) Attempt to change type of variable
// Swift is strongly typed
// If you try to change the type of a variable/constant you get a compiler error
// uncomment this line to see

// myStreetAddress = 575

